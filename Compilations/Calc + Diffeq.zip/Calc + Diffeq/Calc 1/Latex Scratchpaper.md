#math #math111 


$$P'(t) = 5 + 10\sin( \frac{\pi t}{5})$$
$$u = \frac{\pi * t }{5}, du = \frac{\pi}{5}  $$
$$5 \int 1 + 10 \frac{5}{\pi}\int{\sin(u)} = x - 10\cos{u}$$
$$5x - \frac{50\cos{u}}{\pi} = 5x - \frac{50\cos( \pi \frac{x}{5})}{\pi}+C$$
Evaluating 
$$75 - \frac{50\cos(3\pi)}{\pi} = 90.92 - \left( 0 - \frac{50\cos(0)}{\pi}\right)= 91 - 15.92 = 75 + \text{ 35 = 110 foxes}$$

