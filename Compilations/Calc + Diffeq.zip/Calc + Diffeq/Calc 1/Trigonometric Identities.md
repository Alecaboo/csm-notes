#math #math111 #trig #resource 
### Pythagorean Identities

$$sin^{2}\theta + cos^{2}\theta = 1$$
$$1 + cot^{2}\theta = csc^{2}\theta$$
$$tan^{2}\theta + 1 = sec^{2}\theta$$
### Double/Half-Angle Identities

$$sin2\theta = 2sin\theta cos\theta$$
$$cos2\theta = cos^{2}\theta  - sin^{2}\theta$$
$$cos^{2}\theta = \frac{1+cos2\theta}2$$
$$sin^{2}\theta\ = \frac{1-cos2\theta}2$$


