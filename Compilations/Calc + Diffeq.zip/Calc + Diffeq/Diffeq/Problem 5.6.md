$$
\bar{x}(t) = c_{1} \begin{bmatrix}
1 \\
3 
\end{bmatrix}e^{t } + c_{2} \begin{bmatrix}
1 \\
1
\end{bmatrix}e^{t}
$$


$$
\lambda_{1}=-1, \lambda_{2}=1 \text{      Saddle Point}
$$

----

$$
\bar{x}(t)=c_{1} \begin{bmatrix}
1 \\
1
\end{bmatrix}e^{-4t}+ c_{2} \begin{bmatrix}
-2 \\
1
\end{bmatrix}e^{-t}
$$
$$
\text{Both eigenvalues are real negative values, so are stable}
$$
