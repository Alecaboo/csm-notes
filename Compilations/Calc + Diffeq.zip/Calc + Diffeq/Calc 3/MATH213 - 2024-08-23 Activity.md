#math213 #calc #math 
# My bad, completely forgot to submit, uploaded for posterity.
1. Find all the points on the curve that have a slope of 1
$$x=8t + \frac{2}{t^{2}}$$
$$y=8t - \frac{2}{t^{2}}$$
$$\frac{dx}{dt} 8t + 2t^{-2}= 8- 4t^{-3} $$
$$\frac{dy}{dt}8t- 2t^{-2}= 8 + 4t^{-3}$$
$$m = \frac{8+4t^{-3}}{8-4t^{-3}}=1$$
$$t=0\text{ wait, nevermind, negative power, that's cursed}$$
- No solutions

---

Number 2: Determine if the vectors are parallel, orthogonal, or neither

$\vec{u}= <6,-2,-1>$ and $\vec{v}=<2,5,2>$

- Quick dot product check (for sanity)

$$(12) + (-10) + (-2)=0=\perp$$
- Yippeee! a is orthogonal

b. $\vec{u} = 2\hat\imath - \hat\jmath\text{ and } \vec{v}= \frac{-1}{2}\hat\imath + \frac{1}{4}\hat\jmath$
Quick dot product vibe check (I have a bad feeling about this)
$$\left(2 * - \frac{1}{2}\right)+ (-1 * \frac{1}{4})= -1 + \frac{-1}{4} = -\frac{5}{4}$$
- Ok that means you gotta do a cross product here
- 