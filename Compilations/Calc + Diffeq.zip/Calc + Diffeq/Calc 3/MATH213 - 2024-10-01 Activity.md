#math213 #math #calc

## 1.

$$1. \int_{0}^{2}\int_{0}^{1}(2x+y)^{8}dxdy$$

---
## 2.

$$2. \iint_{R}(y+xy^{-2})dA, R= \{(x,y) \mid 0 \leq x \leq 2, 1 \leq y \leq 2\}$$

$$\int_{1}^{2}\int _{0}^{2}(y+xy^{-2}) dxdy$$
$$\int_{1}^{2}\left( yx + \frac{x^{2}y^{-2}}{2}\Big|_{0}^{2}\right)dy$$
$$\int_{1}^{2}( (2y + 2y^{-2}) - (0))dy$$
$$\int_{1}^{2}2y+2y^{-2}dy$$
$$= y^{2}- \frac{2}{3}y^{-3}\Big|_{1}^{2}$$
$$4 - \left(\frac{2}{3}\right)\left(\frac{1}{8}\right)- ( 1 - \frac{2}{3}) $$
$$4 - \frac{2}{24}- 1 + \frac{2}{3}$$
$$= \frac{43}{12}$$



----
## 3.

$$3. \iint_{D} \frac{y}{x^{5}+1}dA, D = \{(x,y)\mid 1 \leq x \leq e, 0 \leq y \leq \ln(x)\}$$
$$\int_{1}^{e}\int_{0}^{\ln(x) }\left(\left( \frac{y}{x^{5}+1}\right)dy\right)dx$$
$$\int_{1}^{e} \left(\frac{1}{x^{5}+1} \int_{0}^{\ln(x)} ydy\right)dx$$
$$\int_{1}^{e}\left( \frac{1}{x^{5}+1}* \frac{y^{2}}{2}\Big|_{0}^{\ln(x)}\right)dx$$
$$\int_{1}^{e}\left( \frac{y^{2}}{2x^{5}+2 }\Big|_{0}^{\ln(x)}\right)dx$$
$$\int_{1}^{e}$$
## 4.

$$4. \iint_{D}x^{3}dA, D = \{(x,y) \mid 1 \leq x \leq e, 0 \leq y \leq \ln(x)\}$$

## 5.

$$5. \text{Find the volume of the solid that lies under the plane } 3x+2y+z =12 \text{ and above }$$
$$R:=\{(x,y) \mid 0 \leq x \leq 1, -2 \leq y \leq 3\}$$
